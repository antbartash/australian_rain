#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='chfpozue'
export NNI_SYS_DIR='/kaggle/working/chfpozue/trials/s5XKq'
export NNI_TRIAL_JOB_ID='s5XKq'
export NNI_OUTPUT_DIR='/kaggle/working/chfpozue/trials/s5XKq'
export NNI_TRIAL_SEQ_ID='57'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU_HB.py' 1>/kaggle/working/chfpozue/trials/s5XKq/stdout 2>/kaggle/working/chfpozue/trials/s5XKq/stderr
echo $? `date +%s%3N` >'/kaggle/working/chfpozue/trials/s5XKq/.nni/state'