#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='chfpozue'
export NNI_SYS_DIR='/kaggle/working/chfpozue/trials/ixXwt'
export NNI_TRIAL_JOB_ID='ixXwt'
export NNI_OUTPUT_DIR='/kaggle/working/chfpozue/trials/ixXwt'
export NNI_TRIAL_SEQ_ID='59'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU_HB.py' 1>/kaggle/working/chfpozue/trials/ixXwt/stdout 2>/kaggle/working/chfpozue/trials/ixXwt/stderr
echo $? `date +%s%3N` >'/kaggle/working/chfpozue/trials/ixXwt/.nni/state'