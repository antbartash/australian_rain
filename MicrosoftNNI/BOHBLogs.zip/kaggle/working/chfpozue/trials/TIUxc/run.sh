#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='chfpozue'
export NNI_SYS_DIR='/kaggle/working/chfpozue/trials/TIUxc'
export NNI_TRIAL_JOB_ID='TIUxc'
export NNI_OUTPUT_DIR='/kaggle/working/chfpozue/trials/TIUxc'
export NNI_TRIAL_SEQ_ID='124'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU_HB.py' 1>/kaggle/working/chfpozue/trials/TIUxc/stdout 2>/kaggle/working/chfpozue/trials/TIUxc/stderr
echo $? `date +%s%3N` >'/kaggle/working/chfpozue/trials/TIUxc/.nni/state'