#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='vd41syun'
export NNI_SYS_DIR='/kaggle/working/vd41syun/trials/Mcy6q'
export NNI_TRIAL_JOB_ID='Mcy6q'
export NNI_OUTPUT_DIR='/kaggle/working/vd41syun/trials/Mcy6q'
export NNI_TRIAL_SEQ_ID='22'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU.py' 1>/kaggle/working/vd41syun/trials/Mcy6q/stdout 2>/kaggle/working/vd41syun/trials/Mcy6q/stderr
echo $? `date +%s%3N` >'/kaggle/working/vd41syun/trials/Mcy6q/.nni/state'