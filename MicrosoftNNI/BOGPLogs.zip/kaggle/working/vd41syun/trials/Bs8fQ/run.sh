#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='vd41syun'
export NNI_SYS_DIR='/kaggle/working/vd41syun/trials/Bs8fQ'
export NNI_TRIAL_JOB_ID='Bs8fQ'
export NNI_OUTPUT_DIR='/kaggle/working/vd41syun/trials/Bs8fQ'
export NNI_TRIAL_SEQ_ID='15'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU.py' 1>/kaggle/working/vd41syun/trials/Bs8fQ/stdout 2>/kaggle/working/vd41syun/trials/Bs8fQ/stderr
echo $? `date +%s%3N` >'/kaggle/working/vd41syun/trials/Bs8fQ/.nni/state'