#!/bin/bash
export NNI_PLATFORM='local'
export NNI_EXP_ID='zms6nf19'
export NNI_SYS_DIR='/kaggle/working/zms6nf19/trials/f2Yrx'
export NNI_TRIAL_JOB_ID='f2Yrx'
export NNI_OUTPUT_DIR='/kaggle/working/zms6nf19/trials/f2Yrx'
export NNI_TRIAL_SEQ_ID='183'
export NNI_CODE_DIR='/kaggle/working'
cd $NNI_CODE_DIR
eval 'python3 /kaggle/working/australian_rain/MicrosoftNNI/model_GPU_HB.py' 1>/kaggle/working/zms6nf19/trials/f2Yrx/stdout 2>/kaggle/working/zms6nf19/trials/f2Yrx/stderr
echo $? `date +%s%3N` >'/kaggle/working/zms6nf19/trials/f2Yrx/.nni/state'